package config

// Config 全局的配置项可以放在这里，不能放app里面，否则会造成循环import
type Config struct {
    RunMode          string
    AgentId          int32
    CorpId           string
    CorpSecret       string
    LevelWithUserMap map[string]string
    ApiAddress       string
}

var C = new(Config)
