package schema

import "time"

// 微信推送告警的参数要求
type WechatPushWarningParams struct {
    ID         string `json:"id"`                        // 唯一标识
    Sender     string `json:"sender" binding:"required"` // 名称
    ToUser     string `json:"touser" binding:"required"` // 接收用户
    AgentId    int    `json:"agentid" binding:"required"`
    Title      string `json:"title" binding:"required"`      // 名称
    Level      int    `json:"level" binding:"required"`      // 级别
    Address    string `json:"address" binding:"required"`    // IP地址
    Content    string `json:"content" binding:"required"`    // 内容
    Status     string `json:"status" binding:"required"`     // 状态
    CorpId     string `json:"corpid" binding:"required"`     // 状态
    CorpSecret string `json:"corpsecret" binding:"required"` // 状态
    // 格式:   "2006-01-02T15:04:05Z"
    UpdatedAt time.Time `json:"updated_at" binding:"required"` // 更新时间
}

// 微信官方给的结果
/*
{
    "errcode": 0,
    "errmsg": "ok",
    "access_token": "token-content",
    "expires_in": 7200
}
*/
type WechatGetTokenResult struct {
    ErrCode int    `json:"errcode"`
    ErrMsg  string `json:"errmsg"`
    Token   string `json:"access_token"`
    Expires int    `json:"expires_in"`
}

// 微信官方给的结果
/*
{
    "errcode": 0, // 必有
    "errmsg": "ok", // 必有
    "invaliduser": "" // 可能没有
}
*/
type WechatPushMsgResult struct {
    Code        int    `json:"errcode"`
    Msg         string `json:"errmsg"`
    InvalidUser string `json:"invaliduser"`
}
