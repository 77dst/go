package injector

import (
    "FMPush/src/config"
    "FMPush/src/router"
    "github.com/gin-gonic/gin"
    ginSwagger "github.com/swaggo/gin-swagger"
    "github.com/swaggo/gin-swagger/swaggerFiles"
)

// InitGinEngine 初始化gin引擎
func InitGinEngine(r router.IRouter) *gin.Engine {
    gin.SetMode(config.C.RunMode)

    app := gin.New()

    // Router register
    _ = r.Register(app)

    // Swagger
    app.GET("/swagger/*any", ginSwagger.WrapHandler(swaggerFiles.Handler))

    return app
}
