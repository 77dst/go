// +build wireinject
// The build tag makes sure the stub is not built in the final build.

package injector

import (
    "FMPush/src/api"
    "FMPush/src/bll/impl/bll"
    "FMPush/src/router"
    "github.com/google/wire"
)

// BuildInjector 生成注入器
func BuildInjector() (*Injector, func(), error) {
    wire.Build(
        InitGinEngine,
        bll.BllSet,
        api.APISet,
        router.RouterSet,
        InjectorSet,
    )
    return new(Injector), nil, nil
}
