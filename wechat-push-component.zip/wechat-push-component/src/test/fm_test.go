package test

import (
    "FMPush/src/schema"
    "bufio"
    "fmt"
    "github.com/stretchr/testify/assert"
    "net/http/httptest"
    "os"
    "strconv"
    "testing"
    "time"
)

const RequireApi = apiPrefix + "v1/wechat/warning"

var Sender = "Testing"
var UserId = "DuShaoFeng"
var AgentId = 1000002
var Address = "TestHost"
var Content = "TestContent"
var Status = "TestStatus"
var CorpId = "d3c0NTdhNzA4YzAwYjZkMTI0"
var CorpSecret = "bDNfZUk3U0Q4ZFFFSURnT1pIT3dIZnNzLUI1N3Vyc3hEQ2t4Rk9XanVwSQ=="
var upAt = time.Now()

func TestT(t *testing.T) {
    scanner := bufio.NewScanner(os.Stdin)
    for scanner.Scan() {
        fmt.Println(scanner.Text()) // Println will add back the final '\n'
    }
    var firstName, lastName string
    fmt.Scanln(&firstName, &lastName)
    // fmt.Scanf("%s %s", &firstName, &lastName)
    fmt.Printf("Hi %s %s!\n", firstName, lastName)
}

func TestWechatError1(t *testing.T) {
    fmt.Println("=====测试参数丢失的情况，该告警应该会在【推送组件内部拦截】，提示发送失败=====")

    w := httptest.NewRecorder()
    addItem := &schema.WechatPushWarningParams{
        ID:      "",
        Sender:  Sender,
        ToUser:  UserId,
        AgentId: AgentId,
        Title:   "Level1 Warning",
        Level:   1,
        Address: Address,
        Content: Content,
        Status:  Status,
        //CorpId:     CorpId,
        //CorpSecret: "bDNfZUk3U0Q4ZFFFSURnT1pIT3dIZnNzLUI1N3Vyc3hEQ2t4Rk9XanVwSQ==",
        UpdatedAt: upAt,
    }
    engine.ServeHTTP(w, newPostRequest(RequireApi, addItem))
    assert.Equal(t, 400, w.Code)
    var addItemRes ResID
    err := parseReader(w.Body, &addItemRes)
    assert.Nil(t, err)
}

func TestWechatError2(t *testing.T) {
    fmt.Println("=====测试参数错配的情况，该告警会因为【微信拒绝】的原因发送失败=====")

    w := httptest.NewRecorder()
    addItem := &schema.WechatPushWarningParams{
        ID:      "",
        Sender:  Sender,
        ToUser:  UserId,
        AgentId: AgentId,
        Title:   "Level1 Warning",
        Level:   1,
        Address: Address,
        Content: Content,
        Status:  Status,
        // 故意写错
        CorpId:     "error",
        CorpSecret: "bDNfZUk3U0Q4ZFFFSURnT1pIT3dIZnNzLUI1N3Vyc3hEQ2t4Rk9XanVwSQ==",
        UpdatedAt:  upAt,
    }
    engine.ServeHTTP(w, newPostRequest(RequireApi, addItem))
    assert.Equal(t, 500, w.Code)
    var addItemRes ResID
    err := parseReader(w.Body, &addItemRes)
    assert.Nil(t, err)
}

func TestWechatL1(t *testing.T) {
    fmt.Println("=====测试1级告警发送=====")

    w := httptest.NewRecorder()
    addItem := &schema.WechatPushWarningParams{
        ID:         "",
        Sender:     Sender,
        ToUser:     UserId,
        AgentId:    AgentId,
        Title:      "Level1",
        Level:      1,
        Address:    Address,
        Content:    Content,
        Status:     Status,
        CorpId:     CorpId,
        CorpSecret: CorpSecret,
        UpdatedAt:  upAt,
    }
    engine.ServeHTTP(w, newPostRequest(RequireApi, addItem))
    assert.Equal(t, 200, w.Code)
    var addItemRes ResID
    err := parseReader(w.Body, &addItemRes)
    assert.Nil(t, err)
}

func TestWechatL2(t *testing.T) {
    fmt.Println("=====测试2级告警发送=====")

    w := httptest.NewRecorder()
    addItem := &schema.WechatPushWarningParams{
        ID:         "",
        Sender:     Sender,
        ToUser:     UserId,
        AgentId:    AgentId,
        Title:      "Level2",
        Level:      2,
        Address:    Address,
        Content:    Content,
        Status:     Status,
        CorpId:     CorpId,
        CorpSecret: CorpSecret,
        UpdatedAt:  upAt,
    }
    engine.ServeHTTP(w, newPostRequest(RequireApi, addItem))
    assert.Equal(t, 200, w.Code)
    var addItemRes ResID
    err := parseReader(w.Body, &addItemRes)
    assert.Nil(t, err)
}

func TestWechatL3(t *testing.T) {
    fmt.Println("=====测试3级告警发送=====")

    w := httptest.NewRecorder()
    addItem := &schema.WechatPushWarningParams{
        ID:         "",
        Sender:     Sender,
        ToUser:     UserId,
        AgentId:    AgentId,
        Title:      "Level3",
        Level:      3,
        Address:    Address,
        Content:    Content,
        Status:     Status,
        CorpId:     CorpId,
        CorpSecret: CorpSecret,
        UpdatedAt:  upAt,
    }
    engine.ServeHTTP(w, newPostRequest(RequireApi, addItem))
    assert.Equal(t, 200, w.Code)
    var addItemRes ResID
    err := parseReader(w.Body, &addItemRes)
    assert.Nil(t, err)
}

func TestWechatEnd(t *testing.T) {
    fmt.Println("/*************************************************")
    fmt.Println("                    测试结束                       ")
    fmt.Println("您应该分别收到1条一级告警，1条二级告警，1条三级告警")
    fmt.Println("发送者应该是:", Sender)
    fmt.Println("内容应该是:", Content)
    fmt.Println("地址应该是:", Address)
    fmt.Println("告警时间应该是:", upAt)
    fmt.Println("")
    fmt.Println("*************************************************/")
}

func TestBenchmark(t *testing.T) {
    fmt.Println("=====测试90个3级告警发送=====")
    for i := 1; i < 91; i++ {
        fmt.Printf("=====发送第%d个=====\n", i)
        w := httptest.NewRecorder()
        addItem := &schema.WechatPushWarningParams{
            ID:         "",
            Sender:     Sender,
            ToUser:     UserId,
            AgentId:    AgentId,
            Title:      "Benchmark test:" + strconv.Itoa(i),
            Level:      3,
            Address:    Address,
            Content:    Content,
            Status:     Status,
            CorpId:     CorpId,
            CorpSecret: CorpSecret,
            UpdatedAt:  upAt,
        }
        engine.ServeHTTP(w, newPostRequest(RequireApi, addItem))
        assert.Equal(t, 200, w.Code)
        var addItemRes ResID
        err := parseReader(w.Body, &addItemRes)
        assert.Nil(t, err)
    }
}
