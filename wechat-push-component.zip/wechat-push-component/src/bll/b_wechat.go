package bll

import (
    "FMPush/src/schema"
    "context"
)

type IWechat interface {
    // 查询数据
    PushMsg(ctx context.Context, params schema.WechatPushWarningParams) *schema.WechatPushMsgResult
}
