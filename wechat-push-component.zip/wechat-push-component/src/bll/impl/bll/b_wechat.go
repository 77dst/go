package bll

import (
    "FMPush/src/bll"
    "FMPush/src/config"
    "FMPush/src/logger"
    "FMPush/src/schema"
    "FMPush/src/util"
    "bytes"
    "context"
    "encoding/base64"
    "encoding/json"
    "fmt"
    "github.com/gin-gonic/gin"
    "github.com/google/wire"
    "io/ioutil"
    "net/http"
    "net/url"
    "time"
)

var _ bll.IWechat = (*Wechat)(nil)

var WechatSet = wire.NewSet(wire.Struct(new(Wechat), "*"), wire.Bind(new(bll.IWechat), new(*Wechat)))

var WechatBaseUrl = "https://qyapi.weixin.qq.com/cgi-bin/"
var WechatGetTokenUrl = WechatBaseUrl + "gettoken"
var WechatPushMsgUrl = WechatBaseUrl + "message/send"

type Wechat struct {
}

var token string
var corpId string
var corpSecret string
var expire int
var sendBusy bool

type WechatMarkdown struct {
    Content string `json:"content"`
}
type WechatPostMsg struct {
    ToUser                 string         `json:"touser"`
    MsgType                string         `json:"msgtype"`
    AgentId                int            `json:"agentid"`
    Markdown               WechatMarkdown `json:"markdown"`
    Safe                   int            `json:"safe"`
    EnableIdTrans          int            `json:"enable_id_trans"`
    EnableDuplicateCheck   int            `json:"enable_duplicate_check"`
    DuplicateCheckInterval int            `json:"duplicate_check_interval"`
}

func (a *Wechat) PushMsg(ctx context.Context, params schema.WechatPushWarningParams) *schema.WechatPushMsgResult {
    if config.C.RunMode == gin.DebugMode {
        logger.Debugf(ctx, "Debug mode send fake warning:"+params.Title+",Content:"+params.Content)
        // 内网调试模式，直接返回true
        return &schema.WechatPushMsgResult{
            Code:        0,
            Msg:         "ok,debug mode.",
            InvalidUser: "",
        }
    }
    if token == "" {
        tokenRes := a.getWechatToken(ctx, params)
        if tokenRes.ErrCode != 0 {
            result := &schema.WechatPushMsgResult{
                Code:        tokenRes.ErrCode,
                Msg:         tokenRes.ErrMsg,
                InvalidUser: "",
            }
            return result
        }
    }
    return a.pushWechatMsg(ctx, params)
}

func (a *Wechat) getWechatToken(ctx context.Context, param schema.WechatPushWarningParams) *schema.WechatGetTokenResult {
    logger.Debugf(ctx, "getWechatToken")

    Url, err := url.Parse(WechatGetTokenUrl)
    if err != nil {
        panic(err.Error())
    }

    corpId = decodeBase64(param.CorpId)
    corpSecret = decodeBase64(param.CorpSecret)
    logger.Debugf(ctx, "corpId："+corpId)
    logger.Debugf(ctx, "corpSecret："+corpSecret)

    params := url.Values{}
    params.Set("corpid", corpId)
    params.Set("corpsecret", corpSecret)
    //如果参数中有中文参数,这个方法会进行URLEncode
    Url.RawQuery = params.Encode()

    urlPath := Url.String()
    resp, err := http.Get(urlPath)
    if resp != nil {
        defer resp.Body.Close()
    }

    tokenRes := &schema.WechatGetTokenResult{
        ErrCode: 501,
        ErrMsg:  "Get token error",
        Token:   "",
        Expires: 0,
    }
    if resp == nil {
        return tokenRes
    }
    s, err := ioutil.ReadAll(resp.Body)

    str := util.S(s)
    err = str.ToJSON(&tokenRes)
    if err == nil {
        token = tokenRes.Token
        expire = tokenRes.Expires
        time.AfterFunc(time.Duration(expire)*time.Second, func() {
            logger.Debugf(context.Background(), "Token timeout.")
            token = ""
        })
    }
    return tokenRes
}

func (a *Wechat) pushWechatMsg(ctx context.Context, param schema.WechatPushWarningParams) *schema.WechatPushMsgResult {
    Url, err := url.Parse(WechatPushMsgUrl)
    result := &schema.WechatPushMsgResult{
        Code:        500,
        Msg:         "",
        InvalidUser: "",
    }
    if err != nil {
        result.Msg = "Parse url error:" + err.Error()
        return result
    }
    params := url.Values{}
    params.Set("access_token", token)
    //如果参数中有中文参数,这个方法会进行URLEncode
    Url.RawQuery = params.Encode()
    urlPath := Url.String()

    timeStr := param.UpdatedAt.Format("2006-01-02 15:04:05")
    content := fmt.Sprintf(`%s
        >发送者：%s
        >级  别：<font color = "red">%d级严重告警</font>
        >时  间：<font color = "warning">%s</font>
        >内  容：<font color = "warning">%s</font>
        >地  址：<font color = "warning">%s</font>
        >
        >请及时处理。`, param.Title, param.Sender, param.Level, timeStr, param.Content, param.Address)

    markdownContent := WechatMarkdown{
        Content: content,
    }
    pushContent := WechatPostMsg{
        ToUser:                 param.ToUser,
        MsgType:                "markdown",
        AgentId:                param.AgentId,
        Markdown:               markdownContent,
        Safe:                   0,
        EnableIdTrans:          0,
        EnableDuplicateCheck:   0,
        DuplicateCheckInterval: 1800,
    }
    if sendBusy {
        logger.Infof(context.Background(), "Wechat busy, try again later.")
        result := &schema.WechatPushMsgResult{
            Code:        400,
            Msg:         "YouTooFast",
            InvalidUser: "",
        }
        return result
    }

    if bs, err := json.Marshal(pushContent); err == nil {
        sendBusy = true
        req := bytes.NewBuffer(bs)
        bodyType := "application/json;charset=utf-8"
        resp, err2 := http.Post(urlPath, bodyType, req)
        time.Sleep(time.Millisecond * 2500)
        sendBusy = false
        if err2 != nil {
            result.Msg = "Post to wechat error:" + err2.Error()
            return result
        }
        body, err := ioutil.ReadAll(resp.Body)
        if err != nil {
            result.Msg = "Read Wechat result error:" + err.Error()
            return result
        } else {
            str := util.S(body)
            str.ToJSON(result)
        }
    } else {
        result.Msg = "Marshal Wechat params error:" + err.Error()
    }
    return result
}

func decodeBase64(encodeString string) string {
    decodeBytes, err := base64.StdEncoding.DecodeString(encodeString)
    if err != nil {
        logger.Debugf(context.Background(), "解码错误."+err.Error())
        return "Decode error."
    }
    return string(decodeBytes)
}
