package bll

import (
    "FMPush/src/bll"
    "FMPush/src/schema"
    "context"
    "github.com/google/wire"
)

var _ bll.IDemo = (*Demo)(nil)

// DemoSet 注入Demo
var DemoSet = wire.NewSet(wire.Struct(new(Demo), "*"), wire.Bind(new(bll.IDemo), new(*Demo)))

// Demo 示例程序
type Demo struct {
}

// Query 查询数据
func (a *Demo) Query(ctx context.Context, params schema.DemoQueryParam, opts ...schema.DemoQueryOptions) (*schema.DemoQueryResult, error) {
    return nil, nil
}
