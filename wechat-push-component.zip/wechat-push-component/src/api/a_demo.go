package api

import (
    "FMPush/src/bll"
    "FMPush/src/ginplus"
    "FMPush/src/logger"
    "FMPush/src/schema"
    "github.com/gin-gonic/gin"
    "github.com/google/wire"
)

// DemoSet 注入Demo
var DemoSet = wire.NewSet(wire.Struct(new(Demo), "*"))

// Demo 示例程序
type Demo struct {
    DemoBll bll.IDemo
}

// Query 查询数据
func (a *Demo) Query(c *gin.Context) {
    ctx := c.Request.Context()
    logger.Printf(ctx, "查询API")
    var params schema.DemoQueryParam
    if err := ginplus.ParseQuery(c, &params); err != nil {
        ginplus.ResError(c, err)
        return
    }

    c.Writer.WriteString("hello")
    c.JSON(200, map[string]interface{}{
        "code":    1,
        "message": "ok",
        "data":    "Hello CMP",
    })

}
