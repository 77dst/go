package api

import (
    "FMPush/src/ginplus"
    "FMPush/src/schema"
    "github.com/gin-gonic/gin"
    "github.com/google/wire"
)

var SmsSet = wire.NewSet(wire.Struct(new(Sms), "*"))

type Sms struct {
}

func (a *Sms) PushWarning(c *gin.Context) {
    var params schema.DemoQueryParam
    if err := ginplus.ParseQuery(c, &params); err != nil {
        ginplus.ResError(c, err)
        return
    }

    c.JSON(200, map[string]interface{}{
        "code":    1,
        "message": "ok",
        "data":    "Push sms warning",
    })

}

func (a *Sms) GetInfo(c *gin.Context) {
    var params schema.DemoQueryParam
    if err := ginplus.ParseQuery(c, &params); err != nil {
        ginplus.ResError(c, err)
        return
    }

    c.JSON(200, map[string]interface{}{
        "code":    1,
        "message": "ok",
        "data":    "Get sms info",
    })

}
