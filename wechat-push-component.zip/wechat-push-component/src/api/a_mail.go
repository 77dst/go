package api

import (
    "FMPush/src/ginplus"
    "FMPush/src/schema"
    "github.com/gin-gonic/gin"
    "github.com/google/wire"
)

var MailSet = wire.NewSet(wire.Struct(new(Mail), "*"))

type Mail struct {
}

func (a *Mail) PushWarning(c *gin.Context) {
    var params schema.DemoQueryParam
    if err := ginplus.ParseQuery(c, &params); err != nil {
        ginplus.ResError(c, err)
        return
    }

    c.JSON(200, map[string]interface{}{
        "code":    1,
        "message": "ok",
        "data":    "Push mail warning",
    })

}

func (a *Mail) GetInfo(c *gin.Context) {
    var params schema.DemoQueryParam
    if err := ginplus.ParseQuery(c, &params); err != nil {
        ginplus.ResError(c, err)
        return
    }

    c.JSON(200, map[string]interface{}{
        "code":    1,
        "message": "ok",
        "data":    "Get mail info",
    })

}
