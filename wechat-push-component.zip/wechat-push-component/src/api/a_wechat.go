package api

import (
    "FMPush/src/bll"
    "FMPush/src/ginplus"
    "FMPush/src/logger"
    "FMPush/src/schema"
    "context"
    "errors"
    "github.com/gin-gonic/gin"
    "github.com/google/wire"
)

var WechatSet = wire.NewSet(wire.Struct(new(Wechat), "*"))

type Wechat struct {
    WechatBll bll.IWechat
}

func (a *Wechat) PushWarning(c *gin.Context) {
    logger.Debugf(context.Background(), "PushWarning from:"+c.Request.RemoteAddr)
    var params schema.WechatPushWarningParams
    if err := ginplus.ParseJSON(c, &params); err != nil {
        ginplus.ResError(c, err)
        return
    }

    result := a.WechatBll.PushMsg(c, params)
    if result.Code != 0 {
        ginplus.ResError(c, errors.New(result.Msg))
        return
    }

    ginplus.ResSuccess(c, result)
}

func (a *Wechat) GetInfo(c *gin.Context) {
    var params schema.DemoQueryParam
    if err := ginplus.ParseQuery(c, &params); err != nil {
        ginplus.ResError(c, err)
        return
    }

    ginplus.ResSuccess(c, "Wechat info give you.")
}
