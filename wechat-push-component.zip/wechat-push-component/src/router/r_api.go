package router

import (
    "github.com/gin-gonic/gin"
)

// RegisterAPI register api group router
func (a *Router) RegisterAPI(app *gin.Engine) {
    g := app.Group("/api")

    //g.Use(middleware.UserAuthMiddleware(a.Auth,
    //    middleware.AllowPathPrefixSkipper("/api/v1/pub/login"),
    //))
    //
    //g.Use(middleware.CasbinMiddleware(a.CasbinEnforcer,
    //    middleware.AllowPathPrefixSkipper("/api/v1/pub"),
    //))
    //
    //g.Use(middleware.RateLimiterMiddleware())

    v1 := g.Group("/v1")
    {
        gWechat := v1.Group("wechat")
        {
            gWechat.POST("warning", a.WechatAPI.PushWarning)
            gWechat.GET("info", a.WechatAPI.GetInfo)
        }
        gMail := v1.Group("mail")
        {
            gMail.POST("warning", a.MailAPI.PushWarning)
            gMail.GET("info", a.MailAPI.GetInfo)
        }
        gSms := v1.Group("sms")
        {
            gSms.POST("warning", a.SmsAPI.PushWarning)
            gSms.GET("info", a.SmsAPI.GetInfo)
        }

        gDemo := v1.Group("demos")
        {
            gDemo.GET("", a.DemoAPI.Query)
        }
    }
}
