package app

import (
    "FMPush/src/config"
    "FMPush/src/errors"
    "FMPush/src/logger"
    "context"
    "encoding/base64"
    "github.com/spf13/viper"
    "os"
)

func InitConfig(runMode string) (func(), error) {
    // 把配置存入全局配置中
    config.C.RunMode = runMode

    if err := loadConfig(); err != nil {
        logger.Printf(context.Background(), "加载配置文件失败:", err.Error())
        createDefaultConfig()
    }

    return func() {
    }, nil
}

func loadConfig() error {
    viper.SetConfigName("config")
    viper.SetConfigType("json")
    viper.AddConfigPath(".")
    if err := viper.ReadInConfig(); err != nil {
        if _, ok := err.(viper.ConfigFileNotFoundError); ok {
            return errors.New("没找到配置文件")
        } else {
            return errors.New("找到配置文件，但是读取失败:" + err.Error())
        }
    }

    if err := viper.Unmarshal(config.C); err != nil {
        return errors.New("配置文件解析失败:" + err.Error())
    }
    // 为了兼容老的nodeJs方式，这里也需要做base64编码
    config.C.CorpId = base64.StdEncoding.EncodeToString([]byte(config.C.CorpId))
    config.C.CorpSecret = base64.StdEncoding.EncodeToString([]byte(config.C.CorpSecret))
    return nil
}

func createDefaultConfig() {
    logger.Printf(context.Background(), "创建默认的配置文件")
    viper.Set("AgentId", 99999)
    viper.Set("CorpId", "corp_id")
    viper.Set("CorpSecret", "corp_secret")
    viper.Set("LevelWithUserMap", map[string]string{
        "level1": "user1|user2",
        "level2": "user1|user2",
        "level3": "user1|user2",
    })
    viper.Set("ApiAddress", "http://api")
    if err := viper.WriteConfigAs("./config.json"); err != nil {
        logger.Errorf(context.Background(), "创建配置文件失败:", err.Error())
    }
    logger.Printf(context.Background(), "配置文件创建完毕，请写入正确配置后再次运行")
    // 重新生成配置后，需要填写有效信息才能运行
    os.Exit(3)
}
