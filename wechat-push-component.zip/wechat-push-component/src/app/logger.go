package app

import (
    "FMPush/src/logger"
    "context"
    "os"
)

// InitLogger 初始化日志模块
func InitLogger(level int) (func(), error) {
    logger.Printf(context.Background(), "日志级别:%d", level)
    logger.SetLevel(level)
    logger.SetFormatter("text")
    logger.SetOutput(os.Stdout)
    return func() {
    }, nil
}
