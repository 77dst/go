package app

import (
    "FMPush/src/injector"
    "FMPush/src/logger"
    _ "FMPush/src/swagger"
    "context"
    "fmt"
    "github.com/gin-gonic/gin"
    "net/http"
    "os"
    "os/signal"
    "sync/atomic"
    "syscall"
    "time"
)

type options struct {
    LogLevel int
    RunMode  string
    Port     int
    Version  string
}

// Option 定义配置项
type Option func(*options)

// Init 应用初始化
func Init(ctx context.Context, opts ...Option) (func(), error) {
    var o options
    for _, opt := range opts {
        opt(&o)
    }
    logger.Printf(ctx, "服务启动，版本号：%s，进程号：%d", o.Version, os.Getpid())

    // 初始化日志模块
    loggerCleanFunc, err := InitLogger(o.LogLevel)
    if err != nil {
        return nil, err
    }

    // 把配置存入全局配置中
    configCleanFunc, err := InitConfig(o.RunMode)
    if err != nil {
        return nil, err
    }

    // 初始化依赖注入器
    injector, injectorCleanFunc, err := injector.BuildInjector()
    if err != nil {
        return nil, err
    }

    // 初始化HTTP服务
    httpServerCleanFunc := InitHTTPServer(ctx, injector.Engine, o.Port)

    // 初始化告警扫描器
    scannerCleanFunc, err := InitScanner(o.Port)
    if err != nil {
        return nil, err
    }

    return func() {
        httpServerCleanFunc()
        injectorCleanFunc()
        loggerCleanFunc()
        configCleanFunc()
        scannerCleanFunc()
    }, nil
}

func SetLogLevel(s int) Option {
    return func(o *options) {
        o.LogLevel = s
    }
}

// SetVersion 设定版本号
func SetVersion(s string) Option {
    return func(o *options) {
        o.Version = s
    }
}

func SetPort(s int) Option {
    return func(o *options) {
        o.Port = s
    }
}

func SetDebugMode(s bool) Option {
    return func(o *options) {
        if s {
            // debug mode
            o.RunMode = gin.DebugMode
        } else {
            // release mode
            o.RunMode = gin.ReleaseMode
        }
    }
}

// InitHTTPServer 初始化http服务
func InitHTTPServer(ctx context.Context, handler http.Handler, port int) func() {
    addr := fmt.Sprintf("0.0.0.0:%d", port)
    srv := &http.Server{
        Addr:         addr,
        Handler:      handler,
        ReadTimeout:  5 * time.Second,
        WriteTimeout: 10 * time.Second,
        IdleTimeout:  15 * time.Second,
    }

    go func() {
        logger.Printf(ctx, "HTTP server is running at %s.", addr)
        var err error
        err = srv.ListenAndServe()
        if err != nil && err != http.ErrServerClosed {
            panic(err)
        }
    }()

    return func() {
        ctx, cancel := context.WithTimeout(ctx, time.Second*time.Duration(30))
        defer cancel()

        srv.SetKeepAlivesEnabled(false)
        if err := srv.Shutdown(ctx); err != nil {
            logger.Errorf(ctx, err.Error())
        }
    }
}

// Run 运行服务
func Run(ctx context.Context, opts ...Option) error {
    var state int32 = 1
    sc := make(chan os.Signal, 1)
    signal.Notify(sc, syscall.SIGHUP, syscall.SIGINT, syscall.SIGTERM, syscall.SIGQUIT)
    cleanFunc, err := Init(ctx, opts...)
    if err != nil {
        return err
    }

EXIT:
    for {
        sig := <-sc
        logger.Printf(ctx, "接收到信号[%s]", sig.String())
        switch sig {
        case syscall.SIGQUIT, syscall.SIGTERM, syscall.SIGINT:
            atomic.CompareAndSwapInt32(&state, 1, 0)
            break EXIT
        case syscall.SIGHUP:
        default:
            break EXIT
        }
    }

    cleanFunc()
    logger.Printf(ctx, "服务退出")
    time.Sleep(time.Second)
    os.Exit(int(atomic.LoadInt32(&state)))
    return nil
}
