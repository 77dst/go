package app

import (
	"FMPush/src/config"
	"FMPush/src/logger"
	"bufio"
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"
)

var pushFileName = "push.list"
var pushList = make(map[string]bool)
var selfAddr string

// InitScanner 初始化告警扫描器，从后台组件获取告警列表
func InitScanner(port int) (func(), error) {
	selfAddr = fmt.Sprintf("http://0.0.0.0:%d/api/v1/wechat/warning", port)
	logger.Info("selfAddr:" + selfAddr)
	loadPushList()
	startScanner()
	return func() {
	}, nil
}

func loadPushList() {
	// 尝试打开文件，如果文件不存在，则会创建它
	file, err := os.OpenFile(pushFileName, os.O_RDWR|os.O_CREATE, 0644)
	if err != nil {
		logger.Error("无法打开和创建推送历史文件")
		return
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := scanner.Text()
		// 将每行内容追加到切片中
		if _, exists := pushList[line]; !exists {
			pushList[line] = true
		}
	}

	if err := scanner.Err(); err != nil {
		logger.Error("读取文件时出错:%s", err)
		return
	}
	logger.Info("恢复告警历史个数:%d", len(pushList))
}

func startScanner() {
	timer := time.NewTicker(time.Second)
	for range timer.C {
		go scanAlert()
	}
}

func scanAlert() {
	response, err := http.Get(config.C.ApiAddress)
	if err != nil {
		logger.Error("无法创建告警请求:" + err.Error())
		return
	}
	defer response.Body.Close()

	// 读取响应内容
	jsonBody, err := ioutil.ReadAll(response.Body)
	if err != nil {
		logger.Error("无法读取告警响应:" + err.Error())
		return
	}

	var alertMap []map[string]interface{}
	if err := json.Unmarshal(jsonBody, &alertMap); err != nil {
		logger.Error("解析 JSON 数据时发生错误:" + err.Error())
		return
	}

	var send = false

	// 遍历所有对象，找到符合条件的对象
	for _, alert := range alertMap {
		if active, ok := alert["newActive"].(bool); ok && active {
			// 找到了 newActive 是 true 的对象
			var id string
			id = alert["uniqueKey"].(string)
			if _, exists := pushList[id]; !exists {
				send = true
				pushList[id] = true
				go pushAlertInner(alert)
			} else {
				logger.Info("这条告警已经推送过:%s", id)
			}

		}
	}
	if send {
		go updatePushFile()
	}
}

// 通过内部接口转发到下·微信接收API
func pushAlertInner(alert map[string]interface{}) {
	uniqueKey := alert["uniqueKey"].(string)
	updateAt := alert["updatedAt"].(string)
	label := alert["labels"].(map[string]interface{})
	name := label["alertname"].(string)
	instance := label["instance"].(string)
	// "severity": "level1",
	severity := label["severity"].(string)
	level := 1
	levelArray := strings.Split(severity, "level")
	if len(levelArray) > 0 {
		level, _ = strconv.Atoi(levelArray[1])
	}
	userList, exist := config.C.LevelWithUserMap[severity]
	if !exist {
		logger.Error("找不到用户列表:" + severity)
	}
	annotations := alert["annotations"].(map[string]interface{})
	description := annotations["description"].(string)

	requestBody := fmt.Sprintf(`{
		"id": "%s",
		"title": "%s",
		"sender": "FMonitor",
		"level": %d,
		"touser": "%s",
		"agentid": %d,
		"address": "%s",
		"content": "%s",
		"status": "新告警",
		"corpid": "%s",
		"corpsecret": "%s",
		"updated_at": "%s"
	}`, uniqueKey, name, level, userList, config.C.AgentId, instance, description, config.C.CorpId, config.C.CorpSecret, updateAt)

	// 发送 POST 请求
	resp, err := http.Post(selfAddr, "application/json", bytes.NewBuffer([]byte(requestBody)))
	if err != nil {
		logger.Error("内部转发告警失败:" + err.Error())
		return
	}
	defer resp.Body.Close()
}

func updatePushFile() {
	file, err := os.Create(pushFileName)
	if err != nil {
		logger.Error("无法创建pushList文件:", err)
		return
	}
	defer file.Close()

	// 逐行将 map 中的键写入文件
	for key := range pushList {
		_, err := file.WriteString(key + "\n")
		if err != nil {
			logger.Error("无法写入到文件:", err)
			return
		}
	}
}
