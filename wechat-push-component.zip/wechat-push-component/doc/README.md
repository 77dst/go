# 生成依赖
```shell
shaofeng@ZJ-OA-DU-SF:/mnt/d/Project/FMPush$ /home/shaofeng/go/bin/wire gen ./src/injector/
wire: FMPush/src/injector: wrote /mnt/d/Project/FMPush/src/injector/wire_gen.go
```

# 编译&运行

```shell
# 编译
shaofeng@ZJ-OA-DU-SF:/mnt/d/Project/FMPush$ go build -ldflags "-X main.VERSION=1.0.1:20200804" cmd/
# windows build
D:\Project\FMPush> go build -ldflags "-X main.VERSION=1.0.1:20200804" .\cmd\
```

# 运行
shaofeng@ZJ-OA-DU-SF:/mnt/d/Project/FMPush$ ./main web -c ./configs/config.toml
INFO[0000] 服务启动，运行模式：debug，版本号：0.0.1，进程号：5813            trace_id=main version=0.0.1
InitGinEngine[GIN-debug] [WARNING] Running in "debug" mode. Switch to "release" mode in production.
 - using env:   export GIN_MODE=release
 - using code:  gin.SetMode(gin.ReleaseMode)

[GIN-debug] GET    /api/v1/demos             --> FMPush/src/api.(*Demo).Query-fm (1 handlers)
[GIN-debug] GET    /swagger/*any             --> github.com/swaggo/gin-swagger.CustomWrapHandler.func1 (1 handlers)
INFO[0000] HTTP server is running at 0.0.0.0:10086.      trace_id=main version=0.0.1
INFO[0010] 查询API                                         trace_id=trace-id-5813-2020.07.23.16.52.51.80357 version=0.0.1
```

# 生成文档
```shell
# 下载依赖
shaofeng@ZJ-OA-DU-SF:/mnt/d/Project/FMPush$ go get -u github.com/swaggo/swag/cmd/swag

# 生成文档
shaofeng@ZJ-OA-DU-SF:/mnt/d/Project/FMPush$ /home/shaofeng/go/bin/swag init --generalInfo ./src/app/swagger.go --output ./src/swagger/
2020/07/23 16:47:56 Generate swagger docs....
2020/07/23 16:47:56 Generate general API Info, search dir:./
2020/07/23 16:47:56 create docs.go at src/swagger/docs.go
2020/07/23 16:47:56 create swagger.json at src/swagger/swagger.json
2020/07/23 16:47:56 create swagger.yaml at src/swagger/swagger.yaml

# 重新编译、运行程序
# 地址
http://127.0.0.1:10086/swagger/index.html
```

# 自动化测试
```shell
shaofeng@ZJ-OA-DU-SF:/mnt/d/Project/FMPush/src/test$ go test --cover
[GIN-debug] [WARNING] Running in "debug" mode. Switch to "release" mode in production.
 - using env:   export GIN_MODE=release
 - using code:  gin.SetMode(gin.ReleaseMode)

[GIN-debug] POST   /api/v1/wechat/warning    --> FMPush/src/api.(*Wechat).PushWarning-fm (1 handlers)
[GIN-debug] GET    /api/v1/wechat/info       --> FMPush/src/api.(*Wechat).GetInfo-fm (1 handlers)
[GIN-debug] POST   /api/v1/mail/warning      --> FMPush/src/api.(*Mail).PushWarning-fm (1 handlers)
[GIN-debug] GET    /api/v1/mail/info         --> FMPush/src/api.(*Mail).GetInfo-fm (1 handlers)
[GIN-debug] POST   /api/v1/sms/warning       --> FMPush/src/api.(*Sms).PushWarning-fm (1 handlers)
[GIN-debug] GET    /api/v1/sms/info          --> FMPush/src/api.(*Sms).GetInfo-fm (1 handlers)
[GIN-debug] GET    /api/v1/demos             --> FMPush/src/api.(*Demo).Query-fm (1 handlers)
[GIN-debug] GET    /swagger/*any             --> github.com/swaggo/gin-swagger.CustomWrapHandler.func1 (1 handlers)
WARN[0000] Key: 'WechatPushWarningParams.UpdatedAt' Error:Field validation for 'UpdatedAt' failed on the 'required' tag  trace_id=trace-id-6375-2020.07.30.10.53.43.997824 version=
PASS
coverage: [no statements]
ok      FMPush/src/test 0.189s
```


