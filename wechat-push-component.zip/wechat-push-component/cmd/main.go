package main

import (
    "FMPush/src/app"
    "FMPush/src/logger"
    "context"
    "github.com/urfave/cli/v2"
    "os"
)

// VERSION 版本号，可以通过编译的方式指定版本号：go build -ldflags "-X main.VERSION=x.x.x"
var VERSION = "2.8.0"

// 1:fatal 2:error,3:warn,4:info,5:debug
var LEVEL = 4
var PORT = 10086

func main() {
    logger.SetVersion(VERSION)
    ctx := logger.NewTraceIDContext(context.Background(), "main")
    var logLevel int
    var port int
    var debugMode bool

    cli.HelpFlag = &cli.BoolFlag{
        Name:    "help",
        Aliases: []string{"h"},
        Usage:   "Show usage info",
    }

    cli.VersionFlag = &cli.BoolFlag{
        Name:    "version",
        Aliases: []string{"v"},
        Usage:   "Show version code",
    }

    newApp := cli.NewApp()
    newApp.Name = "FM推送组件"
    newApp.Version = VERSION
    newApp.Usage = "超级无敌FM推送组件."
    newApp.Authors = []*cli.Author{
        {
            Name: "FMonitor.SFIT",
        },
    }
    newApp.Copyright = "(c) 2020 Serious Enterprise"
    newApp.Flags = []cli.Flag{
        &cli.IntFlag{
            Name:        "level",
            Aliases:     []string{"l"},
            Usage:       "LogLevel:1:fatal 2:error,3:warn,4:info,5:debug",
            DefaultText: "4",
            Destination: &logLevel,
        },
        &cli.IntFlag{
            Name:        "port",
            Aliases:     []string{"p"},
            Usage:       "HttpPort",
            DefaultText: "10086",
            Destination: &port,
        },
        // boolFlag 类型的参数，只要带这个标志位，就是true，没带就是false，无需再指明
        // 比如运行时 只要-d那么 debugMode = true，没有-d就是false，即使指明了-d true，其依然debugMode=true
        &cli.BoolFlag{
            Name:        "debug",
            Aliases:     []string{"d"},
            Usage:       "DebugMode",
            Destination: &debugMode,
        },
    }
    newApp.Commands = cli.Commands{
        &cli.Command{
            Name:    "date",
            Aliases: []string{"c"},
            Usage:   "DisplayBuildTime",
            Action: func(c *cli.Context) error {
                println("BuildTime:" + newApp.Compiled.String())
                return nil
            },
        },
    }
    newApp.Action = func(c *cli.Context) error {
        if logLevel == 0 {
            logLevel = LEVEL
        }
        if port == 0 {
            port = PORT
        }
        return app.Run(ctx,
            app.SetLogLevel(logLevel),
            app.SetPort(port),
            app.SetDebugMode(debugMode),
            app.SetVersion(VERSION))
    }
    err := newApp.Run(os.Args)
    if err != nil {
        logger.Errorf(ctx, err.Error())
    }
}
